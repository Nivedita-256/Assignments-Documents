function [ G ] = gradient_g( h, w )
%GRADIENT Summary of this function goes here
%   Detailed explanation goes here
i = zeros(2*h*(w-1)+2*w*(h-1),1); %index i for matrix G
j = zeros(2*h*(w-1)+2*w*(h-1),1); %index j for matrix G
v = zeros(2*h*(w-1)+2*w*(h-1),1); %value v = 1 or -1 for i,j in matrix G
%for loop Horizontal gradient HG
c= 1;
z=1;
for x = (1 : w-1)
    for y = (1: h)
           i(c) = z;
           j(c) = (y)+h*(x-1);
           v(c) = -1;
           c = c+1;
           i(c) = z;
           j(c) = (y)+x*h;
           v(c)= 1;
           c= c+1; %incrementing vector column index c
           z = z+1; %incrementing z
    end
end
%for loop vertical gradient VG

for x = 1:w %row wise traversal of the image
    for y = 1: h-1 % column wise for a particular row i
           i(c) = z;
           j(c) = (y)+h*(x-1);
           v(c) = -1;
           c = c+1;
           i(c) = z;
           j(c) = (y+1)+h*(x-1);
           v(c)= 1;
           c= c+1;
           z = z+1;
    end
end

% collect triplets here
v = 0.5 * v; % as gradient,g = 0.5 (U_j - U_i)
G = sparse(i,j,v);


