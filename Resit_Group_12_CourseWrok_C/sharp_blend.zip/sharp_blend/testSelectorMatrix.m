% 4x4 matrix where we want to select only the boundary values
U = [ 1, 5,9,13 ; 2,6,10,14;3,7,11,15;4,8,12,16];
ws= 4;
hs=4;

%%%% Selector matrix implementation as used in the blending task

r=1; c=1;
rows=[r*ones(1,ws) r+1:r+hs-1  (r+hs-1)*ones(1,ws-2) r+hs-1:-1:r+1];
cols=[c:c+ws-1 (c+ws-1)*ones(1,hs-2) c+ws-1:-1:c (c)*ones(1,hs-2)];

boundary_pixels = 2 * ws + 2*hs - 4;

i= 1:boundary_pixels;
j= (cols-1)*hs+rows;
v = ones(boundary_pixels,1);

S = sparse(i,j,v,boundary_pixels,ws*hs);
%%%% 

% expected vectors 
expectedi = [1,2,3,4,5,6,7,8,9,10,11,12];
expectedj= [1,5,9,13,14,15,16,12,8,4,3,2];

% check if the vectors match with the ones that we manually calculated by visualizing the matrix 
% if expected vectors are the same as the ones obtained, the implementation is given the right results
if (expectedi - i ==0 )
    if (expectedj - j ==0 )
    disp('true')
    end
else
    disp('not matching')
end



