w = 3;
h = 3;
image = [ 1, 4,7 ; 2,5,8; 3,6,9];

% expected g from matrix
g_calculated = 0.5*[
      image(1,2) - image(1,1);
     image(2,2) - image(2,1);
     image(3,2) - image(3,1);
        
     image(1,3) - image(1,2);
     image(2,3) - image(2,2);
     image(3,3) - image(3,2);
      
     image(2,1) - image(1,1);
     image(3,1) - image(2,1); 
     
     image(2,2) - image(1,2);
     image(3,2) - image(2,2);     
     
     image(2,3) - image(1,3);
     image(3,3) - image(2,3) 
    
    ];
 
% gradient matrix 
G = gradient_g(h,w);
% convert back G from sparse into normal matrix
A=full(G)
%Displaying the resultant matrix
display(A)
% resizing the image to 9*1
U = double(reshape(image,w*h,1));

% gradient vector
g_test = G*U;
%checking if they are equal as expected
tf=isequal(g_calculated,g_test);
disp(tf);
