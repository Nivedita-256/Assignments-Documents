clear all;
close all;
clc;
source=im2double(imread('source.jpg')); % source
target=im2double(imread('target.jpg')); % target image

[ht wt dt]=size(target);
[hs ws ds]=size(source);



% s is the starting column and e is the starting row
s = 220 ;
e = 30;

%% Add target boundary to Us in order to have everything in the same image
Us =target(s-1:s+hs-2, e-1:e+ws-2,:);
Us(2:hs-2,2:ws-2,:) = source(2:hs-2,2:ws-2,:);
Us = double(reshape(Us,ws*hs,ds));
newSource = double(reshape(Us,hs,ws,ds)); 

[hns wns dns] = size(newSource);
%% Inner and boundary gradient for the source image

G = gradient_g(hns,wns); %source

%% Selector matrix calculation
r=1; c=1;
rows=[r*ones(1,ws) r+1:r+hs-1  (r+hs-1)*ones(1,ws-2) r+hs-1:-1:r+1];
cols=[c:c+ws-1 (c+ws-1)*ones(1,hs-2) c+ws-1:-1:c (c)*ones(1,hs-2)];

boundary_pixels = 2 * ws + 2*hs - 4;

i1= 1:boundary_pixels;
j1= (cols-1)*hs+rows;
v = ones(boundary_pixels,1);

S = sparse(i1,j1,v,boundary_pixels,ws*hs);

%% boundary pixels calculation ( Us contains target boundary on it)
Ub = S * Us;

%% Get g
g = G * Us;

%% BOUNDARY GRADIENTS AT ZERO
% put gradients in boundary at zero  = (GHAT)

% first column in zeros
g(1:hs,:)=0;

%last column in zeros
% starting = hs;
% step = (hs+ws);
% g(starting:step:end-hs,:) = 0;



% formula
a = 1;
RHS = G'*g + a*S'*Ub;
LHS = G'*G + a*(S'*S);
U = LHS\RHS;

% blended image
blended = double(reshape(U,hs,ws,ds)); 
target(s-1:s+hs-2,e-1:e+ws-2,:) = blended;

imshow(target);


% selector matriz has the boundary elements , sm into 