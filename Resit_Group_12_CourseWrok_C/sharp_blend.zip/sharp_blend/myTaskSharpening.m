image=imread('blurryImage.png');
[h w d]=size(image);
U = double(reshape(image,w*h,d))/255;
% U=[1 2 3];
% h =1;
% w=3;
cs = 3.5;
cu = 0.5;
%% create sparse matrix G = gradient ( w, h )
G = gradient_g(h,w);

%% Get (g|) =  G * (U|)
g = G * U;

% for each channel, creates the g vector
%for i=1:d
%g(:,i)=G*U(:,i);
%end

% Creates a matrix with h*w,d dimensions full of zeros
% each pixel is a line and each column a color value
U1=zeros(h*w,d);

% for each color
% Minimum is the solution of the linear system
for i=1:d
LHS=G'*G+cu*speye(h*w);
RHS=cs*G'*g(:,i)+cu*U(:,i);
U1(:,i)=LHS\RHS;
end

image1 =uint8(reshape(U1,h,w,d)*255); 
subplot(1,2,1)
imshow(image)
subplot(1,2,2)
imshow(image1)
imwrite(image,'out.png')
